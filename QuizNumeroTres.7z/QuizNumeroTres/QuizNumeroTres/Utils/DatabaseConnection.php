<?php

    class DatabaseConnection {

        private $connection;

        public function __construct(){
            $this->connection = mysqli_connect("127.0.0.1", "root", "", "quizdos", 3306);
        }
    
        public function getConnection(){
            return $this->connection;
        }
    
        public function closeConnection(){
            $this->connection->close();
        }

    }

?>