<?php

include_once("Interfaces/Crud.php");
include_once("../Utils/DatabaseConnection.php");

class ControladorClientes extends DatabaseConnection implements ICrud {

    public function create($cliente){

        $sql = "insert into clientes values (?,?,?,?,?)";
        $stmt = $this->getConnection()->prepare($sql);
        
        $numeroIdentificacion = $cliente->getNumeroIdentificacion();
        $nombres = $cliente->getNombres();
        $apellidos = $cliente->getApellidos();
        $fechaNacimiento = $cliente->getFechaNacimiento() -> format('Y-m-d H:i:s');
        $saldo = $cliente->getSaldo();

        $stmt->bind_param("isssi", $numeroIdentificacion, $nombres, $apellidos, $fechaNacimiento, $saldo);
  
        $stmt->execute();
  
        return $stmt->get_result();

    }

    public function readAll(){

        $sql = "select * from clientes";
        $stmt = $this->getConnection()->prepare($sql);
        $stmt->execute();
    
        return $stmt->get_result();

    }

    public function update($cliente){

        $sql = "update clientes set nombres=?, apellidos=?, fechaNacimiento=?, saldo=? where numeroIdentificacion =? ";
        $stmt = $this->getConnection()->prepare($sql);
        
        $numeroIdentificacion = $cliente->getNumeroIdentificacion();
        $nombres = $cliente->getNombres();
        $apellidos = $cliente->getApellidos();
        $fechaNacimiento = $cliente->getFechaNacimiento() -> format('Y-m-d H:i:s');
        $saldo = $cliente->getSaldo();


        $stmt->bind_param("sssii", $nombres, $apellidos, $fechaNacimiento, $saldo,$numeroIdentificacion);
  
        $stmt->execute();
  
        return $stmt->get_result();

    }

    public function delete($id){

        $sql = "delete from clientes where numeroIdentificacion = ?";
        $stmt = $this->getConnection()->prepare($sql);
  
        $stmt->bind_param("i",$id);
  
        $stmt->execute();
  
        return $stmt->get_result();

    }
    
    public function readById($id){

        $sql = "select * from clientes where numeroIdentificacion = ?;";
        $stmt = $this->getConnection()->prepare($sql);
  
        $stmt->bind_param("i",$id);
  
        $stmt->execute();
  
        return $stmt->get_result();

    }

    public function updateSaldo($id,$saldo){

        $sql = "update clientes set saldo=? where numeroIdentificacion =? ";
        $stmt = $this->getConnection()->prepare($sql);
        
        $numeroIdentificacion = $id;

        $stmt->bind_param("ii", $saldo,$numeroIdentificacion);
  
        $stmt->execute();
  
        return $stmt->get_result();
        
    }

}

?>