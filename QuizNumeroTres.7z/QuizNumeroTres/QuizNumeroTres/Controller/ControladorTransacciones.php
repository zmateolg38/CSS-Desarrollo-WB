<?php

include_once("Interfaces/Crud.php");
include_once("../Utils/DatabaseConnection.php");

class ControladorTransacciones extends DatabaseConnection {

    public function create($transaccion){

        include_once("ControladorClientes.php");
        $controladorClientes = new ControladorClientes();

        $sql = "insert into transacciones values (?,?,?,?,?,?)";
        $stmt = $this->getConnection()->prepare($sql);
        
        $numero = 0;
        $tipo = $transaccion->getTipo();
        $valor = $transaccion->getValor();
        $saldo = $transaccion->getSaldo();
        $fecha = $transaccion->getFecha() -> format('Y-m-d H:i:s');
        $Clientes_numeroIdentificacion = $transaccion->getClientes_numeroIdentificacion();
        
        $controladorClientes -> updateSaldo($Clientes_numeroIdentificacion,$saldo);

        $stmt->bind_param("isiisi", $numero,$tipo, $valor, $saldo, $fecha,$Clientes_numeroIdentificacion);
  
        $stmt->execute();
  
        return $stmt->get_result();

    }

}

?>