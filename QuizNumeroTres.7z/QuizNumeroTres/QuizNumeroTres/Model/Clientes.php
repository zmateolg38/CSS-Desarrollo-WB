<?php

class Clientes {

    /* + -------------- + Attributes + -------------- + */
    private $numeroIdentificacion;
    private $nombres;
    private $apellidos;
    private $fechaNacimiento;
    private $saldo;
    
    /* + -------------- + Constructor Method + -------------- + */
    public function __construct($numeroIdentificacion,$nombres,$apellidos,$fechaNacimiento,$saldo){
        $this -> numeroIdentificacion = $numeroIdentificacion;
        $this -> nombres = $nombres;
        $this -> apellidos = $apellidos;
        $this -> fechaNacimiento = $fechaNacimiento;
        $this -> saldo = $saldo;
    }
       
    /* + -------------- + Access Methods + -------------- + */
    
    public function getNumeroIdentificacion(){
        return $this -> numeroIdentificacion;
    }
    public function getNombres(){
        return $this -> nombres;
    }
    public function getApellidos(){
        return $this -> apellidos;
    }
    public function getFechaNacimiento(){
        return $this -> fechaNacimiento;
    }
    public function getSaldo(){
        return $this -> saldo;
    }
    
    public function setNumeroIdentificacion($numeroIdentificacion):self{
        $this -> numeroIdentificacion=$numeroIdentificacion;
        return $this;
    }
    public function setNombres($nombres):self{
        $this -> nombres=$nombres;
        return $this;
    }
    public function setApellidos($apellidos):self{
        $this -> apellidos=$apellidos;
        return $this;
    }
    public function setFechaNacimiento($fechaNacimiento):self{
        $this -> fechaNacimiento=$fechaNacimiento;
        return $this;
    }
    public function setSaldo($saldo):self{
        $this -> saldo=$saldo;
        return $this;
    }

}

?>