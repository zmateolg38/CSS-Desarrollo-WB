<?php

class Transacciones {

    /* + -------------- + Attributes + -------------- + */
    private $numero;
    private $tipo;
    private $valor;
    private $fecha;
    private $Clientes_numeroIdentificacion;
    private $saldo;
    
    /* + -------------- + Constructor Method + -------------- + */
    public function __construct($tipo,$valor,$fecha,$Clientes_numeroIdentificacion,$saldo){
        $this -> tipo = $tipo;
        $this -> valor = $valor;
        $this -> fecha = $fecha;
        $this -> Clientes_numeroIdentificacion = $Clientes_numeroIdentificacion;
        $this->saldo = $saldo;
    }
       
    /* + -------------- + Access Methods + -------------- + */
    
    public function getNumero(){
        return $this -> numero;
    }
    public function getTipo(){
        return $this -> tipo;
    }
    public function getValor(){
        return $this -> valor;
    }
    public function getFecha(){
        return $this -> fecha;
    }
    public function getClientes_numeroIdentificacion(){
        return $this -> Clientes_numeroIdentificacion;
    }
    public function getSaldo(){
        return $this -> saldo;
    }
    
    public function setNumero($numero){
        $this -> numero=$numero;
    }
    public function setTipo($tipo){
        $this -> tipo=$tipo;
    }
    public function setValor($valor){
        $this -> valor=$valor;
    }
    public function setFecha($fecha){
        $this -> fecha=$fecha;
    }
    public function setClientes_numeroIdentificacion($Clientes_numeroIdentificacion){
        $this -> Clientes_numeroIdentificacion=$Clientes_numeroIdentificacion;
    }
    public function setSaldo($saldo){
        $this -> saldo=$saldo;
    }

    /* Metodos de clase */

    
}

?>