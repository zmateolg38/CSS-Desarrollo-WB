<?php

function calcularSaldo($id,$valor,$tipo){

    include_once("../Controller/ControladorClientes.php");
    $controladorClientes = new ControladorClientes();

    // List by id stament
    $result = $controladorClientes -> readById($id);

    $saldoEnviado;

    while ($fila = $result -> fetch_assoc()){
        
        if($tipo == "C"){
            $saldoEnviado = $fila['saldo']+$valor;
        }

        if($tipo == "R"){
            $saldoEnviado = $fila['saldo']-$valor;
        }

    }

    return $saldoEnviado;

}

/* Imports */
include_once("../Model/Transacciones.php");
include_once("../Controller/ControladorTransacciones.php");

$date = date_create("2022-10-08T22:01");
$saldo = calcularSaldo(1,10,"C");

$transaccion = new Transacciones("C",10,$date,1,$saldo);
$ControladorTransacciones = new ControladorTransacciones();
$ControladorTransacciones -> create($transaccion);

?>