<?php

/* Imports */
include_once("../Model/Clientes.php");
include_once("../Controller/ControladorClientes.php");

/* Utils */
$date = date_create("2022-10-08T22:01");

/* Variables */ /*-*/ /* Arrange */

// Creo
$clienteCreado = new Clientes(3,"Fabian", "Pelufo" ,$date, 8000);
// Edito
$clienteActualizado = new Clientes(1,"Mateo", "Lopez" ,$date, 5000);
$controladorCliente = new ControladorClientes();

// Create stament
$controladorCliente -> create($clienteCreado);


// edit stament
// $controladorCliente -> update($clienteActualizado);


// elinated stament
// $controladorCliente -> delete(1);

?>