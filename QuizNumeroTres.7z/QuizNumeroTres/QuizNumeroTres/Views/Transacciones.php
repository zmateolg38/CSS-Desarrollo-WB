<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Clientes</title>
    </head>

    <body>

        <h2>Formulario clientes</h2>

        <form action="../Controller/Post.php">
        
            <input type="text" placeholder="Numero identificacion">
            <input type="text" placeholder="Nombres">
            <input type="text" placeholder="Apellidos">
            <input type="text" placeholder="Fecha Nacimiento">
            <input type="text" placeholder="Saldo">

            <input type="text" value="cliente" hidden>

            <select name="" id="">

                <option value="create">create</option>
                <option value="update">update</option>
                <option value="delete">delete</option>

            </select>

            <input type="submit">

        </form>

    </body>

</html>