

-- -----------------------------------------------------
-- Schema quizdos
-- -----------------------------------------------------
CREATE SCHEMA 'quizdos';
-- -----------------------------------------------------
-- Schema quizdos
-- -----------------------------------------------------
USE `quizdos` ;

-- -----------------------------------------------------
-- Table `quizdos`.`Clientes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `quizdos`.`Clientes` (
  `numeroIdentificacion` INT NOT NULL,
  `nombres` VARCHAR(45) NOT NULL,
  `apellidos` VARCHAR(45) NOT NULL,
  `fechaNacimiento` DATE NOT NULL,
  `saldo` INT NOT NULL,
  PRIMARY KEY (`numeroIdentificacion`));


-- -----------------------------------------------------
-- Table `quizdos`.`Transacciones`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `quizdos`.`Transacciones` (
  `Numero` INT NOT NULL AUTO_INCREMENT,
  `tipo` ENUM('C', 'R') NOT NULL,
  `Valor` INT NOT NULL,
  `saldo` INT NOT NULL,
  `fecha` VARCHAR(45) NOT NULL,
  `Clientes_numeroIdentificacion` INT NOT NULL,
  PRIMARY KEY (`Numero`),
  CONSTRAINT `fk_Transacciones_Clientes`
    FOREIGN KEY (`Clientes_numeroIdentificacion`)
    REFERENCES `quizdos`.`Clientes` (`numeroIdentificacion`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);


